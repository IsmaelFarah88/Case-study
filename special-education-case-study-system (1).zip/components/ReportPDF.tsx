// This component is no longer in use as PDF generation has been removed from the application.
// The report is now displayed directly on the screen using the ReportView component.
import React from 'react';

const DeprecatedReportPDF: React.FC = () => {
    return null;
};

export default DeprecatedReportPDF;
